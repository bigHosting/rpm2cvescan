#!/bin/sh

/bin/mkdir -p -m 0711 /localservices/rpm2cvescanH
# download the files

#/usr/bin/wget -N "https://www.redhat.com/security/data/oval/com.redhat.rhsa-all.xml"
/usr/bin/wget -N "https://www.redhat.com/security/data/metrics/rpm-to-cve.xml" -O /localservices/rpm2cvescanH/rpm-to-cve.xml
/usr/bin/wget -N "https://www.redhat.com/security/data/oval/com.redhat.rhsa-RHEL5.xml" -O /localservices/rpm2cvescanH/com.redhat.rhsa-RHEL5.xml
/usr/bin/wget -N "https://www.redhat.com/security/data/oval/com.redhat.rhsa-RHEL6.xml" -O /localservices/rpm2cvescanH/com.redhat.rhsa-RHEL6.xml
/usr/bin/wget -N "https://www.redhat.com/security/data/oval/com.redhat.rhsa-RHEL7.xml" -O /localservices/rpm2cvescanH/com.redhat.rhsa-RHEL7.xml
/usr/bin/wget -N "https://www.redhat.com/security/data/metrics/rhsamapcpe.txt" -O /localservices/rpm2cvescanH/rhsamapcpe.txt
/usr/bin/wget -N "https://www.redhat.com/security/data/metrics/cve_dates.txt" -O /localservices/rpm2cvescanH/cve_dates.txt

